﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Base;

namespace TestC
{
    public partial class PlayerSetup : Form
    {
        Utility util = null;
        public PlayerSetup()
        {
            InitializeComponent();
            util = new Utility();
            List<string>  playerName = util.GetPlayersName();
            txtPlayerName1.Text = playerName[0];
            txtPlayerName2.Text = playerName[1];
            lblErrorMessage.Visible = false;
            ((Bitmap)picBlack.Image).MakeTransparent(Color.White);
            ((Bitmap)picWhite.Image).MakeTransparent(Color.White);
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtPlayerName1.Text.Trim()) &&
                !String.IsNullOrEmpty(txtPlayerName2.Text.Trim()))
            {
                if (util.SavePlayerName(txtPlayerName1.Text.Trim(),
                                     txtPlayerName2.Text.Trim()))
                {
                    MessageBox.Show("Players name changes done!!", "Player Setup", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                }
            }
            else
            {
                lblErrorMessage.Visible = true;
                txtPlayerName1.Focus();
            }
        }
    }
}

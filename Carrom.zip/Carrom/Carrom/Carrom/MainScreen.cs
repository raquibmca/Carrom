﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Base;

namespace TestC
{
    public partial class MainScreen : Form
    {
        PlayBoard carrom = null;
        PlayerSetup playerSetup = null;
        public MainScreen()
        {
            InitializeComponent();
            playerSetup = new PlayerSetup();
            carrom = new PlayBoard();
        }

        private void btnPlayerSetup_Click(object sender, EventArgs e)
        {
            playerSetup.ShowDialog(this);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            this.Hide();
            carrom.ShowDialog(this);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainScreen_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}

﻿namespace TestC
{
    partial class PlayBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlayBoard));
            this.btnCW = new System.Windows.Forms.Button();
            this.btnCCW = new System.Windows.Forms.Button();
            this.txtRotatingAngle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.frictionSetter = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.strengthSetter = new System.Windows.Forms.TrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.scoreBoardUpdater = new System.ComponentModel.BackgroundWorker();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.pnlScoreBoardMain = new System.Windows.Forms.Panel();
            this.picScoreBoard = new System.Windows.Forms.PictureBox();
            this.picRed2 = new System.Windows.Forms.PictureBox();
            this.lblWhiteCount = new System.Windows.Forms.Label();
            this.picWhite = new System.Windows.Forms.PictureBox();
            this.lblBlackCount = new System.Windows.Forms.Label();
            this.picBlack = new System.Windows.Forms.PictureBox();
            this.picRed1 = new System.Windows.Forms.PictureBox();
            this.lblBlackBoardPoins = new System.Windows.Forms.Label();
            this.lblWhiteBoardPoins = new System.Windows.Forms.Label();
            this.lblWhitePlayerName = new System.Windows.Forms.Label();
            this.lblBlackPlayerName = new System.Windows.Forms.Label();
            this.lblRedCoveredW = new System.Windows.Forms.Label();
            this.lblRedCoveredB = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picStricker = new System.Windows.Forms.PictureBox();
            this.picBoard = new System.Windows.Forms.PictureBox();
            this.lblFoulMessage = new System.Windows.Forms.Label();
            this.lblPlayerName = new System.Windows.Forms.Label();
            this.timerPromptPlayer = new System.Windows.Forms.Timer(this.components);
            this.timerBoardFinish = new System.Windows.Forms.Timer(this.components);
            this.btnRestartBoard = new System.Windows.Forms.Button();
            this.timerShowFoulText = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.frictionSetter)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.strengthSetter)).BeginInit();
            this.pnlScoreBoardMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picScoreBoard)).BeginInit();
            this.picScoreBoard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRed2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWhite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRed1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStricker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoard)).BeginInit();
            this.picBoard.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCW
            // 
            this.btnCW.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCW.Location = new System.Drawing.Point(151, 19);
            this.btnCW.Name = "btnCW";
            this.btnCW.Size = new System.Drawing.Size(52, 23);
            this.btnCW.TabIndex = 2;
            this.btnCW.Text = "R-CW";
            this.btnCW.UseVisualStyleBackColor = true;
            this.btnCW.Click += new System.EventHandler(this.btnCW_Click);
            // 
            // btnCCW
            // 
            this.btnCCW.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCCW.Location = new System.Drawing.Point(209, 19);
            this.btnCCW.Name = "btnCCW";
            this.btnCCW.Size = new System.Drawing.Size(55, 23);
            this.btnCCW.TabIndex = 2;
            this.btnCCW.Text = "R-CCW";
            this.btnCCW.UseVisualStyleBackColor = true;
            this.btnCCW.Click += new System.EventHandler(this.btnCCW_Click);
            // 
            // txtRotatingAngle
            // 
            this.txtRotatingAngle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRotatingAngle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRotatingAngle.Location = new System.Drawing.Point(119, 19);
            this.txtRotatingAngle.MaxLength = 2;
            this.txtRotatingAngle.Name = "txtRotatingAngle";
            this.txtRotatingAngle.ReadOnly = true;
            this.txtRotatingAngle.Size = new System.Drawing.Size(26, 24);
            this.txtRotatingAngle.TabIndex = 3;
            this.txtRotatingAngle.Text = "5";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(10, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "Rotating Angle";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txtRotatingAngle);
            this.groupBox1.Controls.Add(this.btnCW);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnCCW);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(584, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(268, 57);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rotate Coins";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(645, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 18);
            this.label2.TabIndex = 10;
            this.label2.Text = "Rotating Angle";
            this.label2.Visible = false;
            // 
            // frictionSetter
            // 
            this.frictionSetter.BackColor = System.Drawing.Color.Maroon;
            this.frictionSetter.Location = new System.Drawing.Point(45, 25);
            this.frictionSetter.Maximum = 20;
            this.frictionSetter.Minimum = 10;
            this.frictionSetter.Name = "frictionSetter";
            this.frictionSetter.Size = new System.Drawing.Size(169, 45);
            this.frictionSetter.TabIndex = 11;
            this.frictionSetter.TickFrequency = 2;
            this.frictionSetter.Value = 15;
            this.frictionSetter.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(217, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 18);
            this.label3.TabIndex = 12;
            this.label3.Text = "More";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(4, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 18);
            this.label4.TabIndex = 13;
            this.label4.Text = "Less";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.frictionSetter);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 340);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(267, 76);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Powder on Board";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.strengthSetter);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(3, 256);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(264, 76);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Player Strength";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(6, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 18);
            this.label5.TabIndex = 12;
            this.label5.Text = "Low";
            // 
            // strengthSetter
            // 
            this.strengthSetter.BackColor = System.Drawing.Color.Maroon;
            this.strengthSetter.Location = new System.Drawing.Point(45, 25);
            this.strengthSetter.Maximum = 50;
            this.strengthSetter.Minimum = 5;
            this.strengthSetter.Name = "strengthSetter";
            this.strengthSetter.Size = new System.Drawing.Size(169, 45);
            this.strengthSetter.SmallChange = 5;
            this.strengthSetter.TabIndex = 11;
            this.strengthSetter.TickFrequency = 5;
            this.strengthSetter.Value = 30;
            this.strengthSetter.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(220, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 18);
            this.label6.TabIndex = 13;
            this.label6.Text = "High";
            // 
            // scoreBoardUpdater
            // 
            this.scoreBoardUpdater.WorkerReportsProgress = true;
            this.scoreBoardUpdater.WorkerSupportsCancellation = true;
            this.scoreBoardUpdater.DoWork += new System.ComponentModel.DoWorkEventHandler(this.scoreBoardUpdater_DoWork);
            this.scoreBoardUpdater.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.scoreBoardUpdater_ProgressChanged);
            this.scoreBoardUpdater.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.scoreBoardUpdater_RunWorkerCompleted);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(866, 6);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(53, 433);
            this.listBox1.TabIndex = 22;
            this.listBox1.Visible = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.Black;
            this.checkBox1.Location = new System.Drawing.Point(862, 442);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(58, 22);
            this.checkBox1.TabIndex = 23;
            this.checkBox1.Text = "Shot";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.Visible = false;
            // 
            // pnlScoreBoardMain
            // 
            this.pnlScoreBoardMain.BackgroundImage = global::TestC.Carrom.ScoreBoardBG;
            this.pnlScoreBoardMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlScoreBoardMain.Controls.Add(this.picScoreBoard);
            this.pnlScoreBoardMain.Controls.Add(this.panel5);
            this.pnlScoreBoardMain.Controls.Add(this.groupBox3);
            this.pnlScoreBoardMain.Controls.Add(this.groupBox2);
            this.pnlScoreBoardMain.Location = new System.Drawing.Point(584, 4);
            this.pnlScoreBoardMain.Name = "pnlScoreBoardMain";
            this.pnlScoreBoardMain.Size = new System.Drawing.Size(275, 440);
            this.pnlScoreBoardMain.TabIndex = 25;
            // 
            // picScoreBoard
            // 
            this.picScoreBoard.BackColor = System.Drawing.Color.Transparent;
            this.picScoreBoard.Controls.Add(this.picRed2);
            this.picScoreBoard.Controls.Add(this.lblWhiteCount);
            this.picScoreBoard.Controls.Add(this.picWhite);
            this.picScoreBoard.Controls.Add(this.lblBlackCount);
            this.picScoreBoard.Controls.Add(this.picBlack);
            this.picScoreBoard.Controls.Add(this.picRed1);
            this.picScoreBoard.Controls.Add(this.lblBlackBoardPoins);
            this.picScoreBoard.Controls.Add(this.lblWhiteBoardPoins);
            this.picScoreBoard.Controls.Add(this.lblWhitePlayerName);
            this.picScoreBoard.Controls.Add(this.lblBlackPlayerName);
            this.picScoreBoard.Controls.Add(this.lblRedCoveredW);
            this.picScoreBoard.Controls.Add(this.lblRedCoveredB);
            this.picScoreBoard.Image = global::TestC.Carrom.ScoreBoard1;
            this.picScoreBoard.Location = new System.Drawing.Point(2, 50);
            this.picScoreBoard.Name = "picScoreBoard";
            this.picScoreBoard.Size = new System.Drawing.Size(268, 200);
            this.picScoreBoard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picScoreBoard.TabIndex = 1;
            this.picScoreBoard.TabStop = false;
            this.picScoreBoard.Paint += new System.Windows.Forms.PaintEventHandler(this.picScoreBoard_Paint);
            // 
            // picRed2
            // 
            this.picRed2.BackColor = System.Drawing.Color.Transparent;
            this.picRed2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picRed2.Image = global::TestC.Carrom.Red1;
            this.picRed2.Location = new System.Drawing.Point(198, 133);
            this.picRed2.Name = "picRed2";
            this.picRed2.Size = new System.Drawing.Size(18, 18);
            this.picRed2.TabIndex = 9;
            this.picRed2.TabStop = false;
            this.picRed2.Visible = false;
            // 
            // lblWhiteCount
            // 
            this.lblWhiteCount.AutoSize = true;
            this.lblWhiteCount.BackColor = System.Drawing.Color.Transparent;
            this.lblWhiteCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhiteCount.ForeColor = System.Drawing.Color.Black;
            this.lblWhiteCount.Location = new System.Drawing.Point(242, 34);
            this.lblWhiteCount.Name = "lblWhiteCount";
            this.lblWhiteCount.Size = new System.Drawing.Size(17, 17);
            this.lblWhiteCount.TabIndex = 8;
            this.lblWhiteCount.Text = "0";
            // 
            // picWhite
            // 
            this.picWhite.BackColor = System.Drawing.Color.Transparent;
            this.picWhite.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picWhite.Image = global::TestC.Carrom.White1;
            this.picWhite.Location = new System.Drawing.Point(217, 34);
            this.picWhite.Name = "picWhite";
            this.picWhite.Size = new System.Drawing.Size(18, 18);
            this.picWhite.TabIndex = 7;
            this.picWhite.TabStop = false;
            // 
            // lblBlackCount
            // 
            this.lblBlackCount.AutoSize = true;
            this.lblBlackCount.BackColor = System.Drawing.Color.Transparent;
            this.lblBlackCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBlackCount.ForeColor = System.Drawing.Color.Black;
            this.lblBlackCount.Location = new System.Drawing.Point(242, 133);
            this.lblBlackCount.Name = "lblBlackCount";
            this.lblBlackCount.Size = new System.Drawing.Size(17, 17);
            this.lblBlackCount.TabIndex = 6;
            this.lblBlackCount.Text = "0";
            // 
            // picBlack
            // 
            this.picBlack.BackColor = System.Drawing.Color.Transparent;
            this.picBlack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picBlack.Image = global::TestC.Carrom.Black;
            this.picBlack.Location = new System.Drawing.Point(217, 133);
            this.picBlack.Name = "picBlack";
            this.picBlack.Size = new System.Drawing.Size(18, 18);
            this.picBlack.TabIndex = 5;
            this.picBlack.TabStop = false;
            // 
            // picRed1
            // 
            this.picRed1.BackColor = System.Drawing.Color.Transparent;
            this.picRed1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picRed1.Image = global::TestC.Carrom.Red1;
            this.picRed1.Location = new System.Drawing.Point(198, 34);
            this.picRed1.Name = "picRed1";
            this.picRed1.Size = new System.Drawing.Size(18, 18);
            this.picRed1.TabIndex = 4;
            this.picRed1.TabStop = false;
            this.picRed1.Visible = false;
            // 
            // lblBlackBoardPoins
            // 
            this.lblBlackBoardPoins.AutoSize = true;
            this.lblBlackBoardPoins.BackColor = System.Drawing.Color.Transparent;
            this.lblBlackBoardPoins.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBlackBoardPoins.ForeColor = System.Drawing.Color.Black;
            this.lblBlackBoardPoins.Location = new System.Drawing.Point(212, 107);
            this.lblBlackBoardPoins.Name = "lblBlackBoardPoins";
            this.lblBlackBoardPoins.Size = new System.Drawing.Size(50, 23);
            this.lblBlackBoardPoins.TabIndex = 29;
            this.lblBlackBoardPoins.Text = "00/29";
            // 
            // lblWhiteBoardPoins
            // 
            this.lblWhiteBoardPoins.AutoSize = true;
            this.lblWhiteBoardPoins.BackColor = System.Drawing.Color.Transparent;
            this.lblWhiteBoardPoins.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhiteBoardPoins.ForeColor = System.Drawing.Color.White;
            this.lblWhiteBoardPoins.Location = new System.Drawing.Point(211, 5);
            this.lblWhiteBoardPoins.Name = "lblWhiteBoardPoins";
            this.lblWhiteBoardPoins.Size = new System.Drawing.Size(50, 23);
            this.lblWhiteBoardPoins.TabIndex = 28;
            this.lblWhiteBoardPoins.Text = "00/29";
            // 
            // lblWhitePlayerName
            // 
            this.lblWhitePlayerName.AutoSize = true;
            this.lblWhitePlayerName.BackColor = System.Drawing.Color.Transparent;
            this.lblWhitePlayerName.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhitePlayerName.ForeColor = System.Drawing.Color.White;
            this.lblWhitePlayerName.Location = new System.Drawing.Point(6, 5);
            this.lblWhitePlayerName.Name = "lblWhitePlayerName";
            this.lblWhitePlayerName.Size = new System.Drawing.Size(104, 23);
            this.lblWhitePlayerName.TabIndex = 27;
            this.lblWhitePlayerName.Text = "White Player";
            // 
            // lblBlackPlayerName
            // 
            this.lblBlackPlayerName.AutoSize = true;
            this.lblBlackPlayerName.BackColor = System.Drawing.Color.Transparent;
            this.lblBlackPlayerName.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBlackPlayerName.ForeColor = System.Drawing.Color.Black;
            this.lblBlackPlayerName.Location = new System.Drawing.Point(7, 107);
            this.lblBlackPlayerName.Name = "lblBlackPlayerName";
            this.lblBlackPlayerName.Size = new System.Drawing.Size(103, 23);
            this.lblBlackPlayerName.TabIndex = 26;
            this.lblBlackPlayerName.Text = "Black Player";
            // 
            // lblRedCoveredW
            // 
            this.lblRedCoveredW.AutoSize = true;
            this.lblRedCoveredW.BackColor = System.Drawing.Color.Transparent;
            this.lblRedCoveredW.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRedCoveredW.ForeColor = System.Drawing.Color.DarkRed;
            this.lblRedCoveredW.Location = new System.Drawing.Point(8, 30);
            this.lblRedCoveredW.Name = "lblRedCoveredW";
            this.lblRedCoveredW.Size = new System.Drawing.Size(88, 20);
            this.lblRedCoveredW.TabIndex = 27;
            this.lblRedCoveredW.Text = "Red Covered";
            this.lblRedCoveredW.Visible = false;
            // 
            // lblRedCoveredB
            // 
            this.lblRedCoveredB.AutoSize = true;
            this.lblRedCoveredB.BackColor = System.Drawing.Color.Transparent;
            this.lblRedCoveredB.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRedCoveredB.ForeColor = System.Drawing.Color.DarkRed;
            this.lblRedCoveredB.Location = new System.Drawing.Point(8, 131);
            this.lblRedCoveredB.Name = "lblRedCoveredB";
            this.lblRedCoveredB.Size = new System.Drawing.Size(88, 20);
            this.lblRedCoveredB.TabIndex = 27;
            this.lblRedCoveredB.Text = "Red Covered";
            this.lblRedCoveredB.Visible = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel5.BackgroundImage = global::TestC.Carrom.Board;
            this.panel5.Location = new System.Drawing.Point(1, 8);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(270, 36);
            this.panel5.TabIndex = 25;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(953, 466);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(246, 55);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.BackgroundImage = global::TestC.Carrom.Board;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.lblPlayerName);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(578, 578);
            this.panel2.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.picStricker);
            this.panel1.Controls.Add(this.picBoard);
            this.panel1.Location = new System.Drawing.Point(24, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(528, 528);
            this.panel1.TabIndex = 1;
            // 
            // picStricker
            // 
            this.picStricker.BackColor = System.Drawing.Color.Transparent;
            this.picStricker.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picStricker.Image = global::TestC.Carrom.Stricker1;
            this.picStricker.Location = new System.Drawing.Point(250, 441);
            this.picStricker.Name = "picStricker";
            this.picStricker.Size = new System.Drawing.Size(24, 24);
            this.picStricker.TabIndex = 0;
            this.picStricker.TabStop = false;
            this.picStricker.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picStricker_MouseDown);
            this.picStricker.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picStricker_MouseMove);
            this.picStricker.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picStricker_MouseUp);
            // 
            // picBoard
            // 
            this.picBoard.BackColor = System.Drawing.SystemColors.Control;
            this.picBoard.Controls.Add(this.lblFoulMessage);
            this.picBoard.ErrorImage = null;
            this.picBoard.Image = global::TestC.Carrom.MainBoard1;
            this.picBoard.Location = new System.Drawing.Point(6, 6);
            this.picBoard.Name = "picBoard";
            this.picBoard.Size = new System.Drawing.Size(516, 516);
            this.picBoard.TabIndex = 0;
            this.picBoard.TabStop = false;
            this.picBoard.Paint += new System.Windows.Forms.PaintEventHandler(this.picBoard_Paint);
            this.picBoard.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picBoard_MouseDown);
            // 
            // lblFoulMessage
            // 
            this.lblFoulMessage.BackColor = System.Drawing.Color.Transparent;
            this.lblFoulMessage.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFoulMessage.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblFoulMessage.Location = new System.Drawing.Point(0, 87);
            this.lblFoulMessage.Name = "lblFoulMessage";
            this.lblFoulMessage.Size = new System.Drawing.Size(516, 39);
            this.lblFoulMessage.TabIndex = 1;
            this.lblFoulMessage.Text = "FOUL!! You Missed Aim Line And Striker Choose Pocket.";
            this.lblFoulMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFoulMessage.Visible = false;
            // 
            // lblPlayerName
            // 
            this.lblPlayerName.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerName.ForeColor = System.Drawing.Color.Black;
            this.lblPlayerName.Location = new System.Drawing.Point(66, 555);
            this.lblPlayerName.Name = "lblPlayerName";
            this.lblPlayerName.Size = new System.Drawing.Size(428, 17);
            this.lblPlayerName.TabIndex = 20;
            this.lblPlayerName.Text = "Current Player Name";
            this.lblPlayerName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timerPromptPlayer
            // 
            this.timerPromptPlayer.Interval = 400;
            this.timerPromptPlayer.Tick += new System.EventHandler(this.timerPromptPlayer_Tick);
            // 
            // timerBoardFinish
            // 
            this.timerBoardFinish.Interval = 3000;
            this.timerBoardFinish.Tick += new System.EventHandler(this.timerBoardFinish_Tick);
            // 
            // btnRestartBoard
            // 
            this.btnRestartBoard.BackColor = System.Drawing.Color.Black;
            this.btnRestartBoard.BackgroundImage = global::TestC.Carrom.ScoreBoard1;
            this.btnRestartBoard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRestartBoard.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRestartBoard.ForeColor = System.Drawing.Color.Black;
            this.btnRestartBoard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRestartBoard.Location = new System.Drawing.Point(584, 450);
            this.btnRestartBoard.Name = "btnRestartBoard";
            this.btnRestartBoard.Size = new System.Drawing.Size(275, 40);
            this.btnRestartBoard.TabIndex = 1;
            this.btnRestartBoard.Text = "&Restart Board";
            this.btnRestartBoard.UseVisualStyleBackColor = false;
            this.btnRestartBoard.Visible = false;
            this.btnRestartBoard.Click += new System.EventHandler(this.btnRestartBoard_Click);
            this.btnRestartBoard.Paint += new System.Windows.Forms.PaintEventHandler(this.btnRestartBoard_Paint);
            // 
            // timerShowFoulText
            // 
            this.timerShowFoulText.Interval = 2500;
            this.timerShowFoulText.Tick += new System.EventHandler(this.timerShowFoulText_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.BackgroundImage = global::TestC.Carrom.BaseTiles;
            this.ClientSize = new System.Drawing.Size(864, 578);
            this.Controls.Add(this.btnRestartBoard);
            this.Controls.Add(this.pnlScoreBoardMain);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Carrom";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.frictionSetter)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.strengthSetter)).EndInit();
            this.pnlScoreBoardMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picScoreBoard)).EndInit();
            this.picScoreBoard.ResumeLayout(false);
            this.picScoreBoard.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRed2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWhite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRed1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picStricker)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoard)).EndInit();
            this.picBoard.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox picBoard;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnCW;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCCW;
        private System.Windows.Forms.TextBox txtRotatingAngle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picStricker;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar frictionSetter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar strengthSetter;
        private System.Windows.Forms.Label label6;
        private System.ComponentModel.BackgroundWorker scoreBoardUpdater;
        private System.Windows.Forms.Label lblFoulMessage;
        private System.Windows.Forms.Label lblPlayerName;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel pnlScoreBoardMain;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblWhitePlayerName;
        private System.Windows.Forms.Label lblBlackPlayerName;
        private System.Windows.Forms.PictureBox picScoreBoard;
        private System.Windows.Forms.PictureBox picRed2;
        private System.Windows.Forms.Label lblWhiteCount;
        private System.Windows.Forms.PictureBox picWhite;
        private System.Windows.Forms.Label lblBlackCount;
        private System.Windows.Forms.PictureBox picBlack;
        private System.Windows.Forms.PictureBox picRed1;
        private System.Windows.Forms.Label lblBlackBoardPoins;
        private System.Windows.Forms.Label lblWhiteBoardPoins;
        private System.Windows.Forms.Timer timerPromptPlayer;
        private System.Windows.Forms.Timer timerBoardFinish;
        private System.Windows.Forms.Button btnRestartBoard;
        private System.Windows.Forms.Timer timerShowFoulText;
        private System.Windows.Forms.Label lblRedCoveredW;
        private System.Windows.Forms.Label lblRedCoveredB;

    }
}


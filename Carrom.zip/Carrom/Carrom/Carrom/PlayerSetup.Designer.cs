﻿namespace TestC
{
    partial class PlayerSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlayerSetup));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPlayerName1 = new ZBobb.AlphaBlendTextBox();
            this.txtPlayerName2 = new ZBobb.AlphaBlendTextBox();
            this.btnDone = new System.Windows.Forms.Button();
            this.lblErrorMessage = new System.Windows.Forms.Label();
            this.picWhite = new System.Windows.Forms.PictureBox();
            this.picBlack = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picWhite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlack)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(25, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "1st Player Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(224, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "2nd Player Name";
            // 
            // txtPlayerName1
            // 
            this.txtPlayerName1.BackAlpha = 50;
            this.txtPlayerName1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtPlayerName1.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlayerName1.ForeColor = System.Drawing.Color.Black;
            this.txtPlayerName1.Location = new System.Drawing.Point(247, 34);
            this.txtPlayerName1.MaxLength = 15;
            this.txtPlayerName1.Name = "txtPlayerName1";
            this.txtPlayerName1.Size = new System.Drawing.Size(257, 38);
            this.txtPlayerName1.TabIndex = 1;
            // 
            // txtPlayerName2
            // 
            this.txtPlayerName2.BackAlpha = 50;
            this.txtPlayerName2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtPlayerName2.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlayerName2.ForeColor = System.Drawing.Color.Black;
            this.txtPlayerName2.Location = new System.Drawing.Point(247, 78);
            this.txtPlayerName2.MaxLength = 15;
            this.txtPlayerName2.Name = "txtPlayerName2";
            this.txtPlayerName2.Size = new System.Drawing.Size(256, 38);
            this.txtPlayerName2.TabIndex = 2;
            // 
            // btnDone
            // 
            this.btnDone.BackgroundImage = global::TestC.Carrom.ScoreBoardBG;
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDone.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.ForeColor = System.Drawing.Color.White;
            this.btnDone.Location = new System.Drawing.Point(333, 122);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(170, 45);
            this.btnDone.TabIndex = 3;
            this.btnDone.Text = "&Ok";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // lblErrorMessage
            // 
            this.lblErrorMessage.BackColor = System.Drawing.Color.Transparent;
            this.lblErrorMessage.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrorMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblErrorMessage.Location = new System.Drawing.Point(22, 3);
            this.lblErrorMessage.Name = "lblErrorMessage";
            this.lblErrorMessage.Size = new System.Drawing.Size(441, 28);
            this.lblErrorMessage.TabIndex = 4;
            this.lblErrorMessage.Text = "Enter Player Name.";
            this.lblErrorMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblErrorMessage.Visible = false;
            // 
            // picWhite
            // 
            this.picWhite.BackColor = System.Drawing.Color.Transparent;
            this.picWhite.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picWhite.Image = global::TestC.Carrom.White1;
            this.picWhite.Location = new System.Drawing.Point(3, 45);
            this.picWhite.Name = "picWhite";
            this.picWhite.Size = new System.Drawing.Size(18, 18);
            this.picWhite.TabIndex = 8;
            this.picWhite.TabStop = false;
            // 
            // picBlack
            // 
            this.picBlack.BackColor = System.Drawing.Color.Transparent;
            this.picBlack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picBlack.Image = global::TestC.Carrom.Black;
            this.picBlack.Location = new System.Drawing.Point(3, 86);
            this.picBlack.Name = "picBlack";
            this.picBlack.Size = new System.Drawing.Size(18, 18);
            this.picBlack.TabIndex = 9;
            this.picBlack.TabStop = false;
            // 
            // PlayerSetup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::TestC.Carrom.ScoreBoard1;
            this.ClientSize = new System.Drawing.Size(511, 179);
            this.Controls.Add(this.picBlack);
            this.Controls.Add(this.picWhite);
            this.Controls.Add(this.lblErrorMessage);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.txtPlayerName2);
            this.Controls.Add(this.txtPlayerName1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PlayerSetup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Player Setup";
            this.TransparencyKey = System.Drawing.Color.Magenta;
            ((System.ComponentModel.ISupportInitialize)(this.picWhite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlack)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private ZBobb.AlphaBlendTextBox txtPlayerName1;
        private ZBobb.AlphaBlendTextBox txtPlayerName2;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.Label lblErrorMessage;
        private System.Windows.Forms.PictureBox picWhite;
        private System.Windows.Forms.PictureBox picBlack;
    }
}
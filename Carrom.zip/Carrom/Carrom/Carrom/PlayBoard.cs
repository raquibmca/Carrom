﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Base;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Threading;
using System.IO;
using System.Resources;
using System.Runtime.InteropServices;
using System.Globalization;

namespace TestC
{
    public partial class PlayBoard : Form
    {
        List<BaseCoins> coins = new List<BaseCoins>();
        List<Image> images = new List<Image>();
        ImageAttributes imageAttr = new ImageAttributes();
        BoardBase board = null;
        int rotatAngle = -15;
        int changeAngle;
        List<Bitmap> bitmaps = new List<Bitmap>();
        List<Graphics> coinPositionsGraphics = new List<Graphics>();
        List<Player> players = new List<Player>();
        float playerStrengthConst;
        float frictionConst;
        bool dragging;
        int TargetX;
        int TargetY;
        Dictionary<int, List<int>> coinInPocketCount;
        List<CoinPosition> lastCoinsPositions;
        List<int> allCoinsInPocket;
        int totalScreenShot;
        int imageCount;
        int currentShotIndex;
        Player CurrentPlayer;
        bool isPlayerChanged;
        bool isBoardCointinue;
        bool isWinBoard;
        List<String> playerName;

        public PlayBoard()
        {
            InitializeComponent();
            InitializedBoard();
        }

        private void InitializedBoard()
        {
            int totalCoinToBeCovered = 9;
            currentShotIndex = 0;
            playerStrengthConst = 3f;
            frictionConst = 0.001f;
            allCoinsInPocket = new List<int>();
            Color myColor = Color.FromArgb(100, Color.Blue);
            lblFoulMessage.ForeColor = myColor;
            isBoardCointinue = true;
            isWinBoard = false;
            totalScreenShot = 0;

            scoreBoardUpdater.WorkerReportsProgress = true;
            scoreBoardUpdater.WorkerSupportsCancellation = true;

            Image imgRedCoin = (Image)Carrom.Red1;
            Image imgWhiteCoin = (Image)Carrom.White1;
            Image imgBlackCoin = (Image)Carrom.Black;
            Image imgStrickerCoin = (Image)Carrom.Stricker1;

            imageAttr.SetColorKey(Color.White, Color.White);
            changeAngle = txtRotatingAngle.Text.Trim().Equals(String.Empty) ? 5 : Convert.ToInt32(txtRotatingAngle.Text.Trim());

            images.Clear();
            images.Add(imgRedCoin);
            images.Add(imgWhiteCoin);
            images.Add(imgBlackCoin);
            images.Add(imgStrickerCoin);

            coins.Clear();
            board = new BoardBase(516, coins, images, false, totalCoinToBeCovered);
            board.Friction = ((float)((30 - frictionSetter.Value) * frictionConst));
            board.PlayerStrength = ((float)(strengthSetter.Value * playerStrengthConst));

            Utility util = new Utility();
            playerName = util.GetPlayersName();

            Player whiteCoinPlayer = new Player(playerName[0], ColorType.White, 0, totalCoinToBeCovered);
            Player blackCoinPlayer = new Player(playerName[1], ColorType.Black, 1, totalCoinToBeCovered);

            whiteCoinPlayer.Opponent = blackCoinPlayer;
            blackCoinPlayer.Opponent = whiteCoinPlayer;

            players.Clear();
            players.Add(whiteCoinPlayer);
            players.Add(blackCoinPlayer);

            lblWhitePlayerName.Text = players.FirstOrDefault(fx => fx.CoinColor == ColorType.White).PlayerName;
            lblBlackPlayerName.Text = players.FirstOrDefault(fx => fx.CoinColor == ColorType.Black).PlayerName;

            CurrentPlayer = whiteCoinPlayer;

            CurrentPlayer.IsWin = CurrentPlayer.IsWinner = CurrentPlayer.Opponent.IsWin = CurrentPlayer.Opponent.IsWinner = false;
            CurrentPlayer.BoardPoints = CurrentPlayer.Opponent.BoardPoints = 0;

            lblPlayerName.Text = String.Format("{0} Go For Color [{1}]", CurrentPlayer.PlayerName, CurrentPlayer.CoinColor.ToString());
            lblWhiteBoardPoins.Text = lblBlackBoardPoins.Text = String.Format("{0:00}/29", 0);
            lblWhiteCount.Text = lblBlackCount.Text = "0";

            lblFoulMessage.Visible = false;
            lblFoulMessage.Text = String.Empty;

            lblRedCoveredW.Visible = lblRedCoveredB.Visible = false;

            ((Bitmap)picStricker.Image).MakeTransparent(Color.White);
            ((Bitmap)picRed1.Image).MakeTransparent(Color.White);
            ((Bitmap)picRed2.Image).MakeTransparent(Color.White);
            ((Bitmap)picBlack.Image).MakeTransparent(Color.White);
            ((Bitmap)picWhite.Image).MakeTransparent(Color.White);
            ((Bitmap)picScoreBoard.Image).MakeTransparent(Color.White);

            picRed1.Visible = picRed2.Visible = false;

            picStricker.Parent = picBoard;
            RotateCoinsOnBoard(rotatAngle);

            DirectoryInfo di = new DirectoryInfo(Environment.CurrentDirectory + @"\RenderedImage");
            if (!di.Exists)
            {
                Directory.CreateDirectory(Environment.CurrentDirectory + @"\RenderedImage");
            }
            checkBox1.Checked = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void picBoard_Paint(object sender, PaintEventArgs e)
        {
            #region Coin Related Changes

            //coins.ForEach(coin =>
            //e.Graphics.DrawImage(coin.Image,
            //                     new Rectangle(coin.X, coin.Y, coin.Width, coin.Height),
            //                     0, 0, coin.Width, coin.Height, GraphicsUnit.Pixel, imageAttr));

            #endregion

            #region Commented Board Designer

            //int centerOfCircle;
            //int widthOfCircle;

            //widthOfCircle = 110;
            //centerOfCircle = (board.Width - widthOfCircle) / 2;
            //e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            //e.Graphics.DrawEllipse(new Pen(Color.Blue), new Rectangle(centerOfCircle, centerOfCircle, widthOfCircle, widthOfCircle));

            //widthOfCircle = 120;
            //centerOfCircle = (board.Width - widthOfCircle) / 2;

            //e.Graphics.DrawEllipse(new Pen(Color.Red), new Rectangle(centerOfCircle, centerOfCircle, widthOfCircle, widthOfCircle));

            //e.Graphics.DrawEllipse(new Pen(Color.Black), new Rectangle(-25, -25, 50, 50));
            //e.Graphics.FillEllipse(new SolidBrush(Color.Gray), new Rectangle(-25, -25, 50, 50));

            //e.Graphics.DrawEllipse(new Pen(Color.Black), new Rectangle(board.Width - 25, -25, 50, 50));
            //e.Graphics.FillEllipse(new SolidBrush(Color.Gray), new Rectangle(board.Width - 25, -25, 50, 50));

            //e.Graphics.DrawEllipse(new Pen(Color.Black), new Rectangle(board.Width - 25, board.Width - 25, 50, 50));
            //e.Graphics.FillEllipse(new SolidBrush(Color.Gray), new Rectangle(board.Width - 25, board.Width - 25, 50, 50));

            //e.Graphics.DrawEllipse(new Pen(Color.Black), new Rectangle(-25, board.Width - 25, 50, 50));
            //e.Graphics.FillEllipse(new SolidBrush(Color.Gray), new Rectangle(-25, board.Width - 25, 50, 50));

            //e.Graphics.DrawRectangle(new Pen(new SolidBrush(Color.Black), 1.5f), new Rectangle(56, 56, 404, 404));
            //e.Graphics.DrawRectangle(new Pen(new SolidBrush(Color.Black), 1.5f), new Rectangle(56 + 18, 56 + 18, 404 - 36, 404 - 36));

            ////e.Graphics.DrawRectangle(new Pen(new SolidBrush(Color.Black), 1.5f), new Rectangle(30, 30, 456, 456));
            ////e.Graphics.DrawRectangle(new Pen(new SolidBrush(Color.Black), 1.5f), new Rectangle(112, 112, 292, 292));

            //e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black), 1.5f), new Point(30, 30), new Point(112, 112));
            //e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black), 1.5f), new Point(486, 30), new Point(404, 112));
            //e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black), 1.5f), new Point(30, 486), new Point(112, 404));
            //e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black), 1.5f), new Point(486, 486), new Point(404, 404));

            //e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black), 3f), new Point(coins[0].CenterX, coins[0].CenterY), new Point(TargetX,TargetY));


            #endregion
        }


        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            int x = 17;

            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            e.Graphics.DrawEllipse(new Pen(Color.Red), new Rectangle(20, 20, x, x));
            e.Graphics.FillEllipse(new SolidBrush(Color.Red), new Rectangle(20, 20, x, x));

            e.Graphics.DrawEllipse(new Pen(Color.Yellow), new Rectangle(50, 20, x, x));
            e.Graphics.FillEllipse(new SolidBrush(Color.Yellow), new Rectangle(50, 20, x, x));

            e.Graphics.DrawEllipse(new Pen(Color.Black), new Rectangle(80, 20, x, x));
            e.Graphics.FillEllipse(new SolidBrush(Color.Black), new Rectangle(80, 20, x, x));

        }

        private void btnCW_Click(object sender, EventArgs e)
        {
            rotatAngle += changeAngle;
            RotateCoinsOnBoard(rotatAngle);
        }

        private void btnCCW_Click(object sender, EventArgs e)
        {
            rotatAngle -= changeAngle;
            RotateCoinsOnBoard(rotatAngle);
        }

        private void RotateCoinsOnBoard(int rAngle, bool isRenderStricker = false)
        {
            board.RotateBoardCoinsAtStartup(rAngle);
            bitmaps.Clear();
            coinPositionsGraphics.Clear();

            Bitmap bitmap = Carrom.MainBoard1;
            bitmaps.Add(bitmap);
            coinPositionsGraphics.Add(Graphics.FromImage(bitmap));

            coins.ForEach(coin =>
                {
                    if (coin.CoinType == CoinType.Coin)
                    {
                        coinPositionsGraphics[0].DrawImage(coin.Image,
                                     new Rectangle(coin.X, coin.Y, coin.Width, coin.Height),
                                     0, 0, coin.Width, coin.Height, GraphicsUnit.Pixel, imageAttr);
                    }
                    else if (isRenderStricker)
                    {
                        coinPositionsGraphics[0].DrawImage(coin.Image,
                                             new Rectangle(coin.X, coin.Y, coin.Width, coin.Height),
                                             0, 0, coin.Width, coin.Height, GraphicsUnit.Pixel, imageAttr);
                    }
                });

            picBoard.Refresh();
            picBoard.Image = bitmaps[0];
        }

        private void picStricker_MouseUp(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                dragging = false;
                picStricker.Invalidate();
            }
        }

        private void picStricker_MouseMove(object sender, MouseEventArgs e)
        {
            Point cursorPosition = picBoard.PointToClient(Cursor.Position);
            if (dragging && cursorPosition.X > 73 && cursorPosition.X < 422 && cursorPosition.Y > 30 && cursorPosition.Y < 486)
            {
                picStricker.Location = cursorPosition;
                BaseCoins strikerCoin = coins.FirstOrDefault(fx => fx.CoinType == CoinType.Stricker);
                if (strikerCoin != null)
                {
                    strikerCoin.InitialPosition = new Vector2D(picStricker.Location.X, picStricker.Location.Y);
                    strikerCoin.IntializeAllPositions();
                }
            }
            board.IsFoulFoundAtAim();

        }

        private void picStricker_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dragging = true;
            }
        }


        private void HitStrikerToCoins()
        {
            label2.Text = "";
            picStricker.Visible = false;
            groupBox1.Enabled = false;
            board.Coins = coins;

            Thread.Sleep(100);
            List<CoinPosition> coinPositions = board.StartPlayBoard(TargetX, TargetY);
            RenderFrameImages(coinPositions);
            board.ClearBoardFramePosition();
            Thread.Sleep(100);
        }

        private void RenderFrameImages(List<CoinPosition> coinPositions)
        {
            isPlayerChanged = true;
            int coinPositionInShot = 1;
            currentShotIndex++;
            if (coinPositions != null && coinPositions.Any())
            {
                coinInPocketCount = new Dictionary<int, List<int>>();

                var orderGroups = coinPositions.GroupBy(group => group.FrameIndex)
                                               .OrderBy(order => order.Key)
                                               .Select(select => new { Key = select.Key, Value = select });
                Int16 loopIndex = 0; totalScreenShot++;

                bitmaps.Clear();
                coinPositionsGraphics.Clear();

                int lastKey = orderGroups.Last().Key;
                lastCoinsPositions = orderGroups.Last().Value.Where(fx => fx.CoinIndex > 0).ToList();

                orderGroups.ToList().ForEach(groupCoin =>
                    {
                        Bitmap bitmap = Carrom.MainBoard1;
                        bitmaps.Add(bitmap);
                        coinPositionsGraphics.Add(Graphics.FromImage(bitmap));
                        List<int> pocketCoinsList = new List<int>();
                        groupCoin.Value.ToList().ForEach(coin =>
                            {
                                BaseCoins rendercoin = coins[coin.CoinIndex];
                                if (!coin.IsInPocket)
                                {
                                    coinPositionsGraphics[loopIndex].DrawImage(rendercoin.Image,
                                                 new Rectangle(coin.X, coin.Y, rendercoin.Width, rendercoin.Height),
                                                 0, 0, rendercoin.Width, rendercoin.Height, GraphicsUnit.Pixel, imageAttr);


                                    //coinPositionsGraphics[loopIndex].DrawString(totalScreenShot.ToString(), new Font("Arial", 40), new SolidBrush(Color.FromArgb(128,125,0,0)), new PointF(2.0f, 2.0f));
                                }
                                else
                                {
                                    if (!allCoinsInPocket.Contains(coin.CoinIndex))
                                    {
                                        pocketCoinsList.Add(coin.CoinIndex);
                                        if (coin.CoinIndex != 0)
                                        {
                                            CurrentPlayer.ManagePlayerState(currentShotIndex, coinPositionInShot, rendercoin);
                                            isPlayerChanged = false;
                                            if (CurrentPlayer.IsGotOtherCoin)
                                            {
                                                CurrentPlayer.IsGotOtherCoin = false;
                                                CurrentPlayer.Opponent.UpdateCoinIndexAndPoints(currentShotIndex, coinPositionInShot, rendercoin);
                                                isPlayerChanged = true;
                                            }
                                            coinPositionInShot++;
                                        }
                                        else
                                        {
                                            board.IsFoul = true;
                                        }
                                    }
                                    if (!allCoinsInPocket.Contains(coin.CoinIndex) && coin.CoinIndex != 0)
                                        allCoinsInPocket.Add(coin.CoinIndex);
                                }
                            });

                        if (pocketCoinsList.Any())
                            coinInPocketCount.Add(groupCoin.Key, pocketCoinsList);

                        loopIndex++;
                        totalScreenShot++;

                    });

                board.FoulMessage.Append(board.IsFoul ? board.FoulMessage.Length > 0 ? " And Striker Choose Pocket." : "FOUL!! Striker Choose Pocket." : board.FoulMessage.ToString());
                board.IsFoul = board.IsFoul ? true : board.IsFoulAtAimLine;
                bool playerChangedByCoinLogic = false;
                RestoreCoinPosition(CurrentPlayer.RemoveCoinIndexAndPoints(currentShotIndex, board.IsFoul, out playerChangedByCoinLogic));
                isPlayerChanged = isPlayerChanged || board.IsFoul || playerChangedByCoinLogic;
                scoreBoardUpdater.RunWorkerAsync(loopIndex);
            }
        }

        private void UpdateScoreBoard()
        {
            if (!isWinBoard)
            {
                Player whitePlayer = players.FirstOrDefault(fx => fx.CoinColor == ColorType.White);

                picRed1.Visible = whitePlayer.IsGotRed || whitePlayer.IsRedCovered;
                picRed2.Visible = whitePlayer.Opponent.IsGotRed || whitePlayer.Opponent.IsRedCovered;

                lblBlackCount.Text = String.Format("{0}", whitePlayer.Opponent.GetCoinCountInHand().ToString());
                lblWhiteCount.Text = String.Format("{0}", whitePlayer.GetCoinCountInHand().ToString());

                lblRedCoveredW.Visible = whitePlayer.IsRedCovered;
                lblRedCoveredB.Visible = whitePlayer.Opponent.IsRedCovered;

                if (board.IsFoul)
                {
                    lblFoulMessage.Visible = board.IsFoul;
                    lblFoulMessage.Text = board.FoulMessage.ToString();
                    picStricker.Visible = false;
                    timerShowFoulText.Enabled = true;
                }
            }
        }

        private void picBoard_MouseDown(object sender, MouseEventArgs e)
        {
            if (isBoardCointinue)
            {
                Point point = picBoard.PointToClient(Cursor.Position);
                TargetX = point.X;
                TargetY = point.Y;

                if (e.Button == MouseButtons.Left)
                {
                    isBoardCointinue = false;
                    UpdateTargetPlayer(true);
                    HitStrikerToCoins();
                }
            }
        }

        private void progressBar1_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            board.Friction = ((float)((30 - frictionSetter.Value) * frictionConst));
            label2.Text = board.Friction.ToString();
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            board.PlayerStrength = ((float)(strengthSetter.Value * playerStrengthConst));
            label2.Text = board.PlayerStrength.ToString();
        }

        private void scoreBoardUpdater_DoWork(object sender, DoWorkEventArgs e)
        {
            imageCount = totalScreenShot - Convert.ToInt16(e.Argument);
            int renderImageIndex = 0;
            foreach (Bitmap renderImage in bitmaps)
            {
                Thread.Sleep(27);
                scoreBoardUpdater.ReportProgress(renderImageIndex, renderImage);
                renderImageIndex++;
                imageCount++;
            }
        }

        private void scoreBoardUpdater_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            picBoard.Image = (Bitmap)e.UserState;
            picBoard.Refresh();
            if (checkBox1.Checked)
            {
                picBoard.Image.Save(Environment.CurrentDirectory + @"\RenderedImage\" + imageCount.ToString() + ".jpg");
            }

            if (coinInPocketCount.Select(fx => fx.Key).Contains(e.ProgressPercentage))
            {
                UpdateScoreBoard();
            }
        }

        private void scoreBoardUpdater_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!e.Cancelled)
            {
                Thread.Sleep(1000);

                listBox1.Items.Clear();

                allCoinsInPocket.Distinct().ToList().ForEach(item => listBox1.Items.Add(item.ToString()));

                picBoard.Refresh();
                picBoard.Image = GetLastFrameImage();

                coins[0].Position.X = picStricker.Location.X;
                coins[0].Position.Y = picStricker.Location.Y;

                picStricker.Visible = true;

                UpdatePlayerName();
                UpdateScoreBoard();

                if (isPlayerChanged)
                {
                    board.UpdateAimLinePosition();
                    TransformTheBoard();
                }

                board.IsFoulFoundAtAim();

                board.IsFoul = false;
                isBoardCointinue = true;
            }

        }

        private void UpdateTargetPlayer(bool state)
        {
            lblWhitePlayerName.Visible = true;
            lblBlackPlayerName.Visible = true;
            timerPromptPlayer.Enabled = state;
            //Label targetPlayer = CurrentPlayer.CoinColor == ColorType.White ? lblWhitePlayerName : lblBlackPlayerName;
        }

        private void RestoreCoinPosition(BaseCoins restoreCoin)
        {
            restoreCoin.IsCoinInPocket = false;
            int x = 228 + new Random(5489).Next(0, 59);
            int y = 228 + new Random(2356).Next(0, 59);
            restoreCoin.IntializeAllPositions(x, y);
            CoinPosition restoreCoinPosition = lastCoinsPositions.FirstOrDefault(fx => fx.CoinIndex == restoreCoin.Index);
            restoreCoinPosition.IsInPocket = false;
            restoreCoinPosition.X = x;
            restoreCoinPosition.Y = y;
        }

        private void RestoreCoinPosition(List<int> indexes)
        {
            int counter = 0;
            if (indexes != null)
            {
                while (counter < indexes.Count)
                {
                    int index = indexes[counter];
                    Point point = new Point(
                                            221 + new Random(DateTime.Now.Second * DateTime.Now.Millisecond).Next(0, 58),
                                            221 + new Random(DateTime.Now.Second * DateTime.Now.Minute).Next(0, 58)
                                           );
                    BaseCoins newCoin = new BaseCoins(point.X, point.Y);
                    List<BaseCoins> coinsWithinRestoreArea = coins.Where(fx => IsCoinLieOnRestoreArea(fx)).ToList();
                    if (coinsWithinRestoreArea.All(coin => !newCoin.IsDetectCollision(coin)))
                    {
                        counter++;
                        coins[index].IntializeAllPositions(point.X, point.Y);
                        coins[index].IsCoinInPocket = false;
                        CoinPosition restoreCoinPosition = lastCoinsPositions.FirstOrDefault(fx => fx.CoinIndex == index);
                        restoreCoinPosition.IsInPocket = false;
                        restoreCoinPosition.X = point.X;
                        restoreCoinPosition.Y = point.Y;
                        allCoinsInPocket.Remove(index);
                    }
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TransformTheBoard();
        }

        private bool IsCoinLieOnRestoreArea(BaseCoins coin)
        {
            return !coin.IsCoinInPocket && ((coin.X > 220 && coin.Y > 220 && coin.X < 280 && coin.Y < 280) ||
                                            (coin.X + coin.Width > 220 && coin.Y > 220 && coin.X + coin.Width < 280 && coin.Y < 280) ||
                                            (coin.X + coin.Width > 220 && coin.Y + coin.Width > 220 && coin.X + coin.Width < 280 && coin.Y + coin.Width < 280) ||
                                            (coin.X > 220 && coin.Y + coin.Width > 220 && coin.X < 280 && coin.Y + coin.Width < 280));

        }

        private void UpdatePlayerName()
        {
            lblFoulMessage.Visible = false;
            CurrentPlayer = isPlayerChanged ? CurrentPlayer.Opponent : CurrentPlayer;
            lblPlayerName.Text = String.Format("{0} Go For Color [{1}]", CurrentPlayer.PlayerName, CurrentPlayer.CoinColor.ToString());

            if (CurrentPlayer.IsWin || CurrentPlayer.Opponent.IsWin)
            {
                Player winner = CurrentPlayer.IsWin ? CurrentPlayer : CurrentPlayer.Opponent;

                lblFoulMessage.Visible = true;

                winner.CoinColor = !winner.IsWinner && winner.CoinColor == ColorType.White ? ColorType.Black : ColorType.White;
                winner.Opponent.CoinColor = winner.CoinColor == ColorType.White ? ColorType.Black : ColorType.White;

                if (!winner.IsWinner)
                {
                    lblFoulMessage.Text = String.Format("{0} hand this game by {1} points.", winner.PlayerName, winner.WinningPoints.ToString());
                    picStricker.Visible = false;
                    board.ResetBoard();
                    RotateCoinsOnBoard(rotatAngle);
                    winner.IsWin = winner.Opponent.IsWin = false;

                    lblWhitePlayerName.Text = players.FirstOrDefault(fx => fx.CoinColor == ColorType.White).PlayerName;
                    lblBlackPlayerName.Text = players.FirstOrDefault(fx => fx.CoinColor == ColorType.Black).PlayerName;

                    isPlayerChanged = false;

                    lblWhitePlayerName.Visible = lblBlackPlayerName.Visible = true;

                    coinInPocketCount.Clear();
                    lastCoinsPositions.Clear();
                    allCoinsInPocket.Clear();

                    picStricker.Visible = true;

                    players.ForEach(player => player.ResetPlayerState());

                    CurrentPlayer = players.FirstOrDefault(fx => fx.CoinColor == ColorType.White);
                }
                else
                {
                    lblFoulMessage.Text = String.Format("{0} WIN BOARD BY {1} POINTS.", winner.PlayerName, (winner.BoardPoints - winner.Opponent.BoardPoints).ToString());
                    isWinBoard = true;
                    picStricker.Visible = false;
                    isBoardCointinue = false;
                    UpdateTargetPlayer(false);
                    timerBoardFinish.Enabled = true;
                }

                lblWhiteBoardPoins.Text = winner.CoinColor == ColorType.White ?
                 String.Format("{0:00}/29", winner.BoardPoints) :
                 String.Format("{0:00}/29", winner.Opponent.BoardPoints);

                lblBlackBoardPoins.Text = winner.CoinColor == ColorType.Black ?
                    String.Format("{0:00}/29", winner.BoardPoints) :
                    String.Format("{0:00}/29", winner.Opponent.BoardPoints);
            }
            else
            {
                UpdateTargetPlayer(true);
            }
        }

        public void TransformTheBoard()
        {
            if (lastCoinsPositions != null && lastCoinsPositions.Any())
            {
                Thread.Sleep(1000);
                coins.ForEach(coin =>
                    {
                        if (!coin.IsCoinInPocket && coin.Index != 0)
                        {
                            CoinPosition coinPosition = lastCoinsPositions.FirstOrDefault(fx => fx.CoinIndex == coin.Index);
                            if (coinPosition != null)
                            {
                                coinPosition.X = board.Width - coinPosition.X - coin.Width;
                                coinPosition.Y = board.Width - coinPosition.Y - coin.Width;
                                coin.Position.X = board.Width - coin.Position.X - coin.Width;
                                coin.Position.Y = board.Width - coin.Position.Y - coin.Width;
                            }
                        }
                    });

                picBoard.Refresh();
                picBoard.Image = GetLastFrameImage();
            }
        }

        private Bitmap GetLastFrameImage()
        {
            if (lastCoinsPositions != null)
            {
                Bitmap lastBitmap = Carrom.MainBoard1;

                Graphics lastFrame = Graphics.FromImage(lastBitmap);

                lastCoinsPositions.ForEach(coin =>
                {
                    BaseCoins rendercoin = coins[coin.CoinIndex];
                    if (!coin.IsInPocket)
                    {
                        lastFrame.DrawImage(rendercoin.Image,
                                                     new Rectangle(coin.X, coin.Y, rendercoin.Width, rendercoin.Height),
                                                     0, 0, rendercoin.Width, rendercoin.Height, GraphicsUnit.Pixel, imageAttr);
                    }
                });

                return lastBitmap;
            }
            return null;
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {
            TextureBrush tb = new TextureBrush(Carrom.ScoreBoard1);
            e.Graphics.DrawString("S C O R E  B O A R D", new Font("Bernard MT Condensed", 23, FontStyle.Bold), tb, new PointF(2.0f, 0.0f));
        }

        private void picScoreBoard_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawLine(new Pen(Color.Black, 2.0f), 0, 100, 268, 100);
        }

        private void timerPromptPlayer_Tick(object sender, EventArgs e)
        {
            Label targetPlayer = CurrentPlayer.CoinColor == ColorType.White ? lblWhitePlayerName : lblBlackPlayerName;
            targetPlayer.Visible = !targetPlayer.Visible;
        }

        private void timerBoardFinish_Tick(object sender, EventArgs e)
        {
            scoreBoardUpdater.CancelAsync();
            scoreBoardUpdater.WorkerReportsProgress = false;
            scoreBoardUpdater.WorkerSupportsCancellation = false;
            timerBoardFinish.Enabled = false;
            btnRestartBoard.Visible = true;
        }

        private void btnRestartBoard_Paint(object sender, PaintEventArgs e)
        {
            //System.Drawing.Drawing2D.GraphicsPath buttonPath =
            //                new System.Drawing.Drawing2D.GraphicsPath();

            //// Set a new rectangle to the same size as the button's 
            //// ClientRectangle property.
            //System.Drawing.Rectangle newRectangle = btnRestartBoard.ClientRectangle;

            //// Decrease the size of the rectangle.
            //newRectangle.Inflate(0, 0);

            //// Draw the button's border.
            //e.Graphics.DrawEllipse(System.Drawing.Pens.Black, newRectangle);

            //// Increase the size of the rectangle to include the border.
            //newRectangle.Inflate(1, 1);

            //// Create a circle within the new rectangle.
            //buttonPath.AddEllipse(newRectangle);

            //// Set the button's Region property to the newly created 
            //// circle region.
            //btnRestartBoard.Region = new System.Drawing.Region(buttonPath);
        }

        private void btnRestartBoard_Click(object sender, EventArgs e)
        {
            btnRestartBoard.Visible = false;
            InitializedBoard();
            picStricker.Visible = true;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.F2)
            {
                checkBox1.Visible = !checkBox1.Visible;
                listBox1.Visible = !listBox1.Visible;
                this.Width = checkBox1.Visible ? 940 : 880;
            }
        }

        private void timerShowFoulText_Tick(object sender, EventArgs e)
        {
            board.FoulMessage.Clear();
            lblFoulMessage.Text = String.Empty;
            lblFoulMessage.Visible = false;
            picStricker.Visible = true;
            timerShowFoulText.Enabled = false;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainScreen mainScreen = new MainScreen();
            mainScreen.Show();
        }

        //[DllImport("User32.dll", CharSet = CharSet.Auto)]
        //public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        //[DllImport("User32.dll")]
        //private static extern IntPtr GetWindowDC(IntPtr hWnd);

        //protected override void WndProc(ref Message m)
        //{
        //    base.WndProc(ref m);
        //    const int WM_NCPAINT = 0x85;
        //    if (m.Msg == WM_NCPAINT)
        //    {
        //        IntPtr hdc = GetWindowDC(m.HWnd);
        //        if ((int)hdc != 0)
        //        {
        //            Graphics g = Graphics.FromHdc(hdc);
        //            g.FillRectangle(Brushes.Green, new Rectangle(0, 0, 4800, 23));
        //            g.Flush();
        //            ReleaseDC(m.HWnd, hdc);
        //        }
        //    }
        //}
    }
}

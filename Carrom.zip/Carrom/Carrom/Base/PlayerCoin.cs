﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Base
{
    public class PlayerCoin
    {
        public int ShotIndex { get; set; }
        public int CoinIndex { get; set; }
        public int PositionOfCoinInShot { get; set; }

        public PlayerCoin(int shotIndex, int position, int coinIndex)
        {
            this.ShotIndex = shotIndex;
            this.PositionOfCoinInShot = position;
            this.CoinIndex = coinIndex;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.Drawing.Imaging;

namespace Base
{
    public class BoardBase
    {
        public Rectangle BoardSize { get; set; }
        public List<Image> CoinImages { get; set; }
        public Image BoardImage { get; set; }
        public Bitmap BitMap { get; set; }
        public List<BaseCoins> Coins { get; set; }
        public int Width { get; set; }
        public int FrameIndex { get; set; }
        public float Friction { get; set; }
        public float PlayerStrength { get; set; }
        public bool IsFoul { get; set; }
        public bool IsFoulAtAimLine { get; set; }
        public StringBuilder FoulMessage { get; set; }

        private List<AimLine> AimLines { get; set; }
        private List<Pocket> Pockets { get; set; }
        private BoardWall Wall { get; set; }
        private List<CoinPosition> FramePositions { get; set; }
        private Boolean IsAiming { get; set; }
        private List<Point> XCordinateOfCoinAtAimLine { get; set; }
        private bool ShowIndexOnCoin { get; set; }
        private int TotalCoinToBeCovered { get; set; }

        public BoardBase(int width, List<BaseCoins> coins, List<Image> images, bool showIndexOnCoin = false, int totalCoinToBeCovered = 9)
        {
            this.Width = width;
            this.Coins = coins;
            this.CoinImages = images;
            this.ShowIndexOnCoin = showIndexOnCoin;
            this.TotalCoinToBeCovered = totalCoinToBeCovered;
            LoadPockets();
            LoadBoardsWallAndFrame();
            LoadAimLines();
        }

        private void LoadAimLines()
        {
            FoulMessage = new StringBuilder();
            AimLines = new List<AimLine>();
            XCordinateOfCoinAtAimLine = new List<Point>();
            AimLines.Add(new AimLine(74, 442, 442, 460));
        }

        private void LoadBoardsWallAndFrame()
        {
            FrameIndex = 0;
            Wall = new BoardWall(this.Width);
            FramePositions = new List<CoinPosition>();
        }

        private void LoadPockets()
        {
            Pockets = new List<Pocket>();
            Pockets.Add(new Pocket(0, 0));
            Pockets.Add(new Pocket(0, 516));
            Pockets.Add(new Pocket(516, 516));
            Pockets.Add(new Pocket(516, 0));
        }

        public void UpdateAimLinePosition(AimLinePosition aimLinePosition = AimLinePosition.Bottom)
        {
            AimLine aimLine = AimLines.FirstOrDefault(fx => fx.Position == aimLinePosition);
            XCordinateOfCoinAtAimLine.Clear();
            Coins.ForEach(coin =>
            {
                if (coin.Index != 0 && !coin.IsCoinInPocket && aimLine.IsCrossAimLine(coin))
                {
                    XCordinateOfCoinAtAimLine.Add(new Point(coin.X, coin.X + coin.Width));
                }
            });
        }

        public void IsFoulFoundAtAim()
        {
            FoulMessage.Clear();
            IsFoulAtAimLine = false;
            IsFoulAtAimLine = XCordinateOfCoinAtAimLine.Any(point =>
                (Coins[0].X >= point.X || Coins[0].X + Coins[0].Width >= point.X) &&
                (Coins[0].X < point.Y || Coins[0].X + Coins[0].Width < point.Y))
                || !(Coins[0].Y > 435 && Coins[0].Y < 444);

            FoulMessage.Append(IsFoulAtAimLine ? "FOUL!! You Missed Aim Line" : String.Empty);
        }

        public void RotateBoardCoinsAtStartup(int rotatingAngle)
        {
            LoadCoins(rotatingAngle);
        }

        public List<CoinPosition> StartPlayBoard(int x, int y)
        {
            //20 is the maximum velocity
            double v = 20 * (this.PlayerStrength / 100.0);
            //Calculates the cue angle, and the translate velocity (normal velocity)
            double dx = x - Coins[0].CenterX;
            double dy = y - Coins[0].CenterY;
            double h = (double)(Math.Sqrt(Math.Pow(dx, 2) + Math.Pow(dy, 2)));
            double sin = dy / h;
            double cos = dx / h;

            Coins[0].IsCoinInPocket = false;
            Coins[0].TranslateVelocity.X = v * cos;
            Coins[0].TranslateVelocity.Y = v * sin;
            Vector2D normalVelocity = Coins[0].TranslateVelocity.Normalize();
            IsAiming = true;
            FrameIndex = 0;
            while (IsAiming)
            {
                PlayCoins();
            }
            UpdateAimLinePosition();
            return FramePositions;
        }

        public void ClearBoardFramePosition()
        {
            FramePositions.Clear();
        }

        public void ResetBoard(bool isStartNewGame = false)
        {
            IsAiming = false;
            ClearBoardFramePosition();
            //IsFoul = false;
            if (isStartNewGame)
            {

            }
        }

        private void PlayCoins()
        {
            bool isCollisionFound = true;
            List<BaseCoins> copyCoins = Coins;
            while (isCollisionFound)
            {
                copyCoins.ForEach(coin =>
                    {
                        if (!coin.IsCoinInPocket)
                        {
                            coin = IsCoinInBoardPocket(coin);
                            isCollisionFound = false;

                            RectangleCollision collisionDirection = Wall.Collision(coin);
                            if (collisionDirection != RectangleCollision.None && !coin.IsCoinInPocket)
                            {
                                isCollisionFound = true;
                                Wall.ResolveCollision(coin, collisionDirection);
                            }

                            Coins.ForEach(collisionCoin =>
                            {
                                if (!collisionCoin.ID.Equals(coin.ID) && !collisionCoin.IsCoinInPocket && coin.IsDetectCollision(collisionCoin))
                                {
                                    isCollisionFound = true;
                                    coin.ResolveCollision(collisionCoin);
                                }
                            });

                            if (coin.TranslateVelocity.X != 0.0d || coin.TranslateVelocity.Y != 0.0d)
                            {

                                double signalXVelocity = coin.TranslateVelocity.X >= 0 ? 1.0 : -1.0;
                                double signalYVelocity = coin.TranslateVelocity.Y >= 0 ? 1.0 : -1.0;
                                double absXVelocity = Math.Abs(coin.TranslateVelocity.X);
                                double absYVelocity = Math.Abs(coin.TranslateVelocity.Y);

                                Vector2D absVelocity = new Vector2D(absXVelocity, absYVelocity);

                                Vector2D normalizedDiff = absVelocity.Normalize();

                                absVelocity.X = absVelocity.X * (1.0 - this.Friction) - normalizedDiff.X * this.Friction;
                                absVelocity.Y = absVelocity.Y * (1.0 - this.Friction) - normalizedDiff.Y * this.Friction;

                                if (absVelocity.X < 0d)
                                    absVelocity.X = 0d;

                                if (absVelocity.Y < 0d)
                                    absVelocity.Y = 0d;

                                double vx = absVelocity.X * signalXVelocity;
                                double vy = absVelocity.Y * signalYVelocity;

                                if (double.IsNaN(vx))
                                    vx = 0;

                                if (double.IsNaN(vy))
                                    vy = 0;

                                coin.TranslateVelocity = new Vector2D(vx, vy);
                            }
                        }
                    });

                copyCoins.ForEach(newPositionCoin =>
                    {
                        newPositionCoin.Position.X += newPositionCoin.TranslateVelocity.X;
                        newPositionCoin.Position.Y += newPositionCoin.TranslateVelocity.Y;
                    });
            }

            //if (copyCoins.Any(fx => fx.X != fx.LastPosition.X || fx.Y != fx.LastPosition.Y))
            //{
            copyCoins.ForEach(newPositionCoin =>
                {
                    newPositionCoin.LastPosition.X = newPositionCoin.X;
                    newPositionCoin.LastPosition.Y = newPositionCoin.Y;
                    FramePositions.Add(new CoinPosition(newPositionCoin.X, newPositionCoin.Y, FrameIndex, newPositionCoin.Index, newPositionCoin.IsCoinInPocket));
                });
            //}

            double sum = copyCoins.Sum(fx => fx.TranslateVelocity.X + fx.TranslateVelocity.Y);
            IsAiming = sum != 0.0d;

            FrameIndex++;

            Coins = copyCoins;
        }

        private void LoadCoins(int rotatingAngle = -15)
        {
            Point[] p = new Point[] { new Point(24, 488), new Point(474, 494), new Point(475, 21), new Point(18, 35), new Point(493, 477), new Point(37, 11), new Point(13, 471), };

            //int x = p[0].X;// this.Width / 2 - 9;
            //int y = p[0].Y;// this.Width / 2 - 9;

            int x = this.Width / 2 - 9;
            int y = this.Width / 2 - 9;

            double length = 0.0d;
            Coins.Clear();
            Coins.Add(new BaseCoins("Stricker", CoinImages[3], 243, 442, CoinType.Stricker, ColorType.None, 0));
            Coins.Add(new BaseCoins("Red1", changeImage(CoinImages[0], 1, ShowIndexOnCoin), x, y, CoinType.Coin, ColorType.Red, 1));
            double adjustDiameter = Coins[1].Diameter + 0.6;
            int i;
            int angle;
            int j = 1;
            for (i = 2; i < (TotalCoinToBeCovered * 2) + 2; i++)
            {
                length = i < 8 ? adjustDiameter : (i - 6) % 2 == 0 ? adjustDiameter * 2 : Math.Sqrt(3) * Coins[1].Diameter;
                angle = i < 8 ? 60 : 30;
                int newX = Coins[1].X + (int)(length * Math.Cos((Math.PI / 180) * ((angle * i) + rotatingAngle)));
                int newY = Coins[1].Y + (int)(length * Math.Sin((Math.PI / 180) * ((angle * i) + rotatingAngle)));
                bool isWhite = i % 2 == 0;
                string coinId = String.Format("{0}{1}", isWhite ? "White" : "Black", i);
                Coins.Add(new BaseCoins(coinId, changeImage(CoinImages[isWhite ? 1 : 2], i, ShowIndexOnCoin), newX, newY, CoinType.Coin, isWhite ? ColorType.White : ColorType.Black, i));
                //Coins.Add(new BaseCoins(coinId, changeImage(CoinImages[isWhite ? 1 : 2], i, ShowIndexOnCoin), p[j].X, p[j].Y, CoinType.Coin, isWhite ? ColorType.White : ColorType.Black, i));
                j++;
            }
        }

        private BaseCoins IsCoinInBoardPocket(BaseCoins coin)
        {
            foreach (Pocket pocket in Pockets)
            {
                if (pocket.IsCoinFallIntoPocket(coin))
                {
                    coin.TranslateVelocity.X =
                    coin.TranslateVelocity.Y = 0.0d;
                    break;
                }
            }
            return coin;
        }

        private Image changeImage(Image img, int i, bool ShowIndexOnCoin)
        {
            Image cloneImage = (Image)img.Clone();
            if (ShowIndexOnCoin)
            {
                Graphics g = Graphics.FromImage(cloneImage);
                PointF p = i < 10 ? new PointF(3.5f, 0.4f) : new PointF(0.1f, 0.1f);
                SolidBrush brush = i % 2 == 0 ? new SolidBrush(Color.Black) : new SolidBrush(Color.AntiqueWhite);
                g.DrawString(i.ToString(), new Font("Latha", 10.0f, FontStyle.Bold), brush, p);
            }
            return cloneImage;
        }

    }
}

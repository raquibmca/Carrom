﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Base
{
    public class AimLine
    {
        private int X1 { get; set; }
        private int X2 { get; set; }
        private int Height1 { get; set; }
        private int Height2 { get; set; }
        public AimLinePosition Position { get; set; }

        public AimLine(int x1, int x2, int heightY1, int heightY2, AimLinePosition position = AimLinePosition.Bottom)
        {
            this.X1 = x1;
            this.X2 = x2;
            this.Height1 = heightY1;
            this.Height2 = heightY2;
            this.Position = position;
        }

        public bool IsCrossAimLine(BaseCoins coin)
        {
            bool isCross = false;
            switch (Position)
            {
                case AimLinePosition.Bottom:
                    if ((coin.X >= X1 || coin.X + coin.Width >= X1) && (coin.X - coin.Width <= X2 || coin.X <= X2) &&
                        (coin.Y >= Height1 - coin.Width && coin.Y <= Height2))
                        isCross = true;
                    break;
                case AimLinePosition.Top:
                    break;
            }

            return isCross;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Base
{
    public class Player
    {
        public string PlayerName { get; set; }
        public ColorType CoinColor { get; set; }
        public int BoardAttempt { get; set; }
        public Player Opponent { get; set; }
        public bool IsGotRed { get; set; }
        public bool IsRedCovered { get; set; }
        public bool IsGotOtherCoin { get; set; }
        public bool IsWinner { get; set; }
        public bool IsWin { get; set; }
        public int BoardPoints { get; set; }
        public int BoardWinningPoints { get; set; }
        public int WinningPoints { get; set; }
        public int PlayerIndex { get; private set; }

        private List<PlayerCoin> CoinIndexs { get; set; }
        private int RedCoveredShotIndex { get; set; }
        private int TotalCoinToBeCovered { get; set; }
        private bool IsAllCoinCoveredExceptRed { get; set; }
        private bool CurrentIndexIsForRedCoin { get; set; }
        private bool IsAllCoinCovered { get; set; }

        public Player(string playerName, ColorType coinColor, int playerIndex, int totalCoinToBeCovered, int boardWinningPoints = 29)
        {
            this.PlayerName = playerName;
            this.CoinColor = coinColor;
            this.PlayerIndex = playerIndex;
            this.BoardWinningPoints = boardWinningPoints;
            this.TotalCoinToBeCovered = totalCoinToBeCovered;
            CoinIndexs = new List<PlayerCoin>();
        }

        public void ManagePlayerState(int shotIndex, int position, BaseCoins coin)
        {
            if (coin.Color == ColorType.Red || coin.Color == CoinColor)
            {
                CoinIndexs.Add(new PlayerCoin(shotIndex, position, coin.Index));
                IsGotRed = IsGotRed ? IsGotRed : coin.Color == ColorType.Red;
                CurrentIndexIsForRedCoin = coin.Color == ColorType.Red;
                if (IsGotRed && !IsRedCovered)
                {
                    IsRedCovered = !CoinIndexs.Last().CoinIndex.Equals(1);
                    RedCoveredShotIndex = shotIndex;
                }

                IsAllCoinCoveredExceptRed = CoinIndexs.Count(fx => !fx.CoinIndex.Equals(1)) == TotalCoinToBeCovered && !IsRedCovered && !Opponent.IsRedCovered;
                IsAllCoinCovered = CoinIndexs.Count(fx => !fx.CoinIndex.Equals(1)) == TotalCoinToBeCovered && (IsRedCovered || Opponent.IsRedCovered);
                UpdatePlayersStateOnWin();
            }
            else
            {
                IsGotOtherCoin = true;
            }
        }

        public void UpdateCoinIndexAndPoints(int shotIndex, int position, BaseCoins coin)
        {
            CoinIndexs.Add(new PlayerCoin(shotIndex, position, coin.Index));
            IsAllCoinCoveredExceptRed = CoinIndexs.Count(fx => !fx.CoinIndex.Equals(1)) == TotalCoinToBeCovered && !IsRedCovered && !Opponent.IsRedCovered;
            IsAllCoinCovered = CoinIndexs.Count(fx => !fx.CoinIndex.Equals(1)) == TotalCoinToBeCovered && (IsRedCovered || Opponent.IsRedCovered);
            UpdatePlayersStateOnWin();
        }

        public int GetCoinCountInHand()
        {
            return CoinIndexs.Count(fx => fx.CoinIndex != 1);
        }

        public List<int> RemoveCoinIndexAndPoints(int shotIndex, bool isFoulFound, out bool isPlayerChanged)
        {
            List<int> indexes = null;

            isFoulFound = !isFoulFound && IsAllCoinCoveredExceptRed ? true : isFoulFound;
            isPlayerChanged = isFoulFound;
            if (CoinIndexs.Any() && isFoulFound)
            {
                indexes = new List<int>();
                indexes.AddRange(CoinIndexs.Where(fx => fx.ShotIndex == shotIndex).Select(index => index.CoinIndex));
                List<PlayerCoin> lastPlayerCoins = CoinIndexs.Where(fx => fx.ShotIndex != shotIndex).OrderBy(o => o.ShotIndex).ToList();
                if (lastPlayerCoins.Any() && IsRedCovered && RedCoveredShotIndex == shotIndex)
                {
                    indexes.Add(lastPlayerCoins.Last().CoinIndex);
                    IsGotRed = false;
                    IsRedCovered = false;
                    RedCoveredShotIndex = 0;
                }
                else if (lastPlayerCoins.Where(fx => fx.CoinIndex != 1).Any())
                {
                    indexes.Add(lastPlayerCoins.Where(fx => fx.CoinIndex != 1).Last().CoinIndex);
                }
            }
            if (CoinIndexs.Any() && IsGotRed && !IsRedCovered && !CurrentIndexIsForRedCoin)
            {
                indexes = indexes != null ? indexes : new List<int>();
                indexes.Add(CoinIndexs.Last().CoinIndex);
                IsGotRed = false;
            }

            if (indexes != null && indexes.Any())
            {
                indexes.ForEach(index =>
                {
                    CoinIndexs.Remove(CoinIndexs.FirstOrDefault(fx => fx.CoinIndex == index));
                });
            }

            if (!Opponent.IsRedCovered && Opponent.IsAllCoinCoveredExceptRed)
            {
                indexes = indexes != null ? indexes : new List<int>();
                Opponent.IsAllCoinCoveredExceptRed = false;
                indexes.Add(Opponent.CoinIndexs.Last().CoinIndex);
                indexes.ForEach(index =>
                    {
                        Opponent.CoinIndexs.Remove(CoinIndexs.FirstOrDefault(fx => fx.CoinIndex == index));
                    });
                indexes.AddRange(Opponent.Opponent.RemoveCoinIndexAndPoints(shotIndex, true, out isFoulFound));
            }

            CurrentIndexIsForRedCoin = IsAllCoinCoveredExceptRed = false;

            if (indexes != null)
            {
                //If last coin covered and stricker choose pocket.
                BoardPoints = IsWin || IsWinner ? BoardPoints - WinningPoints : BoardPoints;

                IsWin = IsWinner = IsAllCoinCovered = false;
            }

            return indexes;
        }

        private void UpdatePlayersStateOnWin()
        {
            if (IsAllCoinCovered)
            {
                IsWin = true;
                WinningPoints = IsAllCoinCovered && IsRedCovered ? (CoinIndexs.Count - Opponent.CoinIndexs.Count) + 4 : (CoinIndexs.Count - Opponent.CoinIndexs.Count) + 1;
                BoardPoints += WinningPoints;
                IsWinner = BoardPoints >= BoardWinningPoints;
                //ResetPlayerState();
                //Opponent.ResetPlayerState();
            }

            //if (Opponent.IsAllCoinCovered)
            //{
            //    Opponent.IsWin = true;
            //    Opponent.WinningPoints = Opponent.IsAllCoinCovered && Opponent.IsRedCovered ? (Opponent.CoinIndexs.Count - Opponent.Opponent.CoinIndexs.Count) + 4 :
            //                                                        (Opponent.CoinIndexs.Count - Opponent.Opponent.CoinIndexs.Count) + 1;
            //    Opponent.BoardPoints += Opponent.WinningPoints;
            //    Opponent.IsWinner = Opponent.BoardPoints >= 10;
            //    //Opponent.ResetPlayerState();
            //    //Opponent.Opponent.ResetPlayerState();
            //}
        }

        public void ResetPlayerState()
        {
            IsGotRed = false;
            IsRedCovered = false;
            IsAllCoinCovered = false;
            IsGotOtherCoin = false;
            CoinIndexs.Clear();
            RedCoveredShotIndex = 0;
            IsAllCoinCoveredExceptRed = false;
            CurrentIndexIsForRedCoin = false;
            IsWin = false;
            IsWinner = false;
        }
    }
}

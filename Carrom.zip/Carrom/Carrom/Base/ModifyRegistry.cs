using System;
using Microsoft.Win32;      

namespace Base
{
	public class ModifyRegistry
	{
        private string SubKey { get { return "SOFTWARE\\CarromSetup"; } }
		
		private RegistryKey baseRegistryKey = Registry.CurrentUser;
		
		public RegistryKey BaseRegistryKey
		{
			get { return baseRegistryKey; }
			set	{ baseRegistryKey = value; }
		}

		public string Read(string KeyName)
		{
			RegistryKey rk = baseRegistryKey ;
			RegistryKey sk1 = rk.OpenSubKey(SubKey);
			if ( sk1 == null )
			{
				return null;
			}
			else
			{
				try 
				{
					return (string)sk1.GetValue(KeyName.ToUpper());
				}
				catch (Exception)
				{
					return null;
				}
			}
		}	

		public bool Write(string KeyName, object Value)
		{
			try
			{
				RegistryKey rk = baseRegistryKey ;
				RegistryKey sk1 = rk.CreateSubKey(SubKey);
				sk1.SetValue(KeyName.ToUpper(), Value);

				return true;
			}
			catch (Exception)
			{
				return false;
			}
		}

		public int SubKeyCount()
		{
			try
			{
				RegistryKey rk = baseRegistryKey ;
				RegistryKey sk1 = rk.OpenSubKey(SubKey);
				if ( sk1 != null )
					return sk1.SubKeyCount;
				else
					return 0; 
			}
			catch (Exception)
			{
				return 0;
			}
		}
	}
}

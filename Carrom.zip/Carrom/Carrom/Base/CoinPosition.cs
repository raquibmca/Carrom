﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Base
{
    public class CoinPosition
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int FrameIndex { get; set; }
        public int CoinIndex { get; set; }
        public bool IsInPocket { get; set; }

        public CoinPosition(int x, int y, int frameIndex, int coinIndex, bool isInPocket)
        {
            this.X = x;
            this.Y = y;
            this.FrameIndex = frameIndex;
            this.CoinIndex = coinIndex;
            this.IsInPocket = isInPocket;
        }
    }
}

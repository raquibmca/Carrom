﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Base
{
    public class BoardWall
    {
        public BoardWall(int width)
        {
            this.Width = width;
            this.Direction = ForcedDirection.None;
        }

        public ForcedDirection Direction { get; set; }
        public int Width { get; set; }

        public RectangleCollision Collision(BaseCoins coin)
        {
            RectangleCollision collision = RectangleCollision.None;

            if (coin.TranslateVelocity.X == 0.0d && coin.TranslateVelocity.Y == 0.0d)
                return collision;

            if (coin.Position.X <= 0)
            {
                collision = RectangleCollision.Left;
                coin.Position.X = 0;
            }
            else if (coin.Position.Y <= 0)
            {
                collision = RectangleCollision.Top;
                coin.Position.Y = 0;
            }
            else if (coin.Position.X + coin.Diameter >= this.Width && coin.Position.Y >  0)
            {
                collision = RectangleCollision.Right;
                coin.Position.X = this.Width - coin.Width;
            }
            else if (coin.Position.Y + coin.Diameter >= this.Width)
            {
                collision = RectangleCollision.Bottom;
                coin.Position.Y = this.Width - coin.Width;
            }
            return collision;
        }

        public void ResolveCollision(BaseCoins coin, RectangleCollision collision)
        {
            float absorption = 0.9f;

            //if (this.Direction == ForcedDirection.None)
            //{
                switch (collision)
                {
                    case RectangleCollision.Right:
                    case RectangleCollision.Left:
                        coin.TranslateVelocity.X *= -1.0d * absorption;
                        break;
                    case RectangleCollision.Bottom:
                    case RectangleCollision.Top:
                        coin.TranslateVelocity.Y *= -1.0d * absorption;
                        break;
                }
            //}
            //else
            //{
            //    Vector2D position = new Vector2D(coin.Position.X + Width / 2, coin.Position.Y + Width / 2);

            //    switch (this.Direction)
            //    {
            //        case ForcedDirection.Up:
            //            coin.TranslateVelocity.Y *= -0.5d;
            //            coin.TranslateVelocity.X = coin.TranslateVelocity.Y * -0.5d;
            //            break;
            //        case ForcedDirection.Down:
            //            coin.TranslateVelocity.Y *= -0.5d;
            //            coin.TranslateVelocity.X = coin.TranslateVelocity.Y * -0.5d;
            //            break;
            //    }

            //    return;
            //    // get the mtd
            //    Vector2D delta = (position.Subtract(coin.Position));
            //    float d = delta.Lenght();
            //    // minimum translation distance to push balls apart after intersecting
            //    Vector2D mtd = delta.Multiply((float)(((this.Width * 2) - d) / d));

            //    // resolve intersection --
            //    // inverse mass quantities
            //    float im1 = 0.5f;
            //    float im2 = coin.Weight;

            //    // push-pull them apart based off their mass
            //    coin.Position = coin.Position.Subtract(mtd.Multiply(im2 / (im1 + im2)));

            //    // impact speed
            //    Vector2D v = coin.TranslateVelocity.Multiply(-1.0d);
            //    float vn = v.Dot(mtd.Normalize());
            //    //float vn = 1;

            //    // sphere intersecting but moving away from each other already
            //    if (vn > 0.0f)
            //        return;

            //    // collision impulse
            //    float i = Math.Abs((float)((-(1.0f + 0.1) * vn) / (im1 + im2)));
            //    Vector2D impulse = mtd.Multiply(i);

            //    switch (this.Direction)
            //    {
            //        case ForcedDirection.Up:
            //            coin.TranslateVelocity = coin.TranslateVelocity.Add(new Vector2D((double)0, (double)vn));
            //            break;
            //        case ForcedDirection.Down:
            //            coin.TranslateVelocity = coin.TranslateVelocity.Subtract(new Vector2D((double)0, (double)vn));
            //            break;
            //        case ForcedDirection.Left:
            //            coin.TranslateVelocity = coin.TranslateVelocity.Subtract(new Vector2D((double)vn, (double)0));
            //            break;
            //        case ForcedDirection.Right:
            //            coin.TranslateVelocity = coin.TranslateVelocity.Add(new Vector2D((double)vn, (double)0));
            //            break;
            //    }
            //}
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Base
{
    public class BaseCoins
    {
        public readonly double Radius;
        public readonly double Diameter;
        public readonly int Points;
        public readonly float Weight;
        public readonly int Height;
        public readonly int Width;
        public readonly int CoinBase45;

        public BaseCoins(string coidId, Image image, double x, double y, CoinType coinType, ColorType color, int index = 0)
        {
            this.ID = coidId;
            this.Image = image;
            this.Radius = coinType == CoinType.Coin ? 9 : 12;
            this.Diameter = this.Radius * 2;
            this.CoinBase45 = (int)(Math.Cos(Math.PI / 4) * Radius);
            this.Weight = coinType == CoinType.Coin ? 1 / 2f : 1 / 1.5f;
            this.Height = this.Width = coinType == CoinType.Coin ? 18 : 24;
            this.CoinType = coinType;
            this.Color = color;
            this.Points = coinType == CoinType.Coin ? color == ColorType.Red ? 5 : 1 : -1;
            this.TranslateVelocity = new Vector2D(0, 0);
            this.InitialPosition = new Vector2D(x, y);
            this.Position = new Vector2D(x, y);
            this.LastPosition = new Vector2D(x, y);
            this.IsCoinInPocket = false;
            this.Index = index;
        }

        public BaseCoins(int x, int y)
        {
            this.TranslateVelocity = new Vector2D(1, 1);
            this.InitialPosition = new Vector2D(x, y);
            this.Position = new Vector2D(x, y);
            this.LastPosition = new Vector2D(x, y);
            this.IsCoinInPocket = false;
            this.Radius =  9;
            this.Diameter = this.Radius * 2;
        }

        public string ID { get; set; }
        public Rectangle Size { get; private set; }
        public CoinType CoinType { get; set; }
        public ColorType Color { get; set; }
        public Image Image { get; set; }
        public Vector2D InitialPosition { get; set; }
        public Vector2D Position { get; set; }
        public Vector2D TranslateVelocity { get; set; }
        public Vector2D LastPosition { get; set; }
        public bool IsCoinInPocket { get; set; }
        public int X { get { return (int)Position.X; } set { Position.X = value; } }
        public int Y { get { return (int)Position.Y; } set { Position.Y = value; } }
        public int CenterX { get { return (int)(Position.X + this.Radius); } }
        public int CenterY { get { return (int)(Position.Y + this.Radius); } }
        public int Index { get; set; }

        public BaseCoins this[int index]
        {
            get
            {
                return this[index];
            }
        }

        public bool IsDetectCollision(BaseCoins coin)
        {
            if (!coin.IsCoinInPocket && !IsCoinInPocket && (this.TranslateVelocity.X != 0.0d ||
                                                            this.TranslateVelocity.Y != 0.0d ||
                                                            coin.TranslateVelocity.X != 0.0d ||
                                                            coin.TranslateVelocity.Y != 0.0d))
            {
                //float xd = (float)(this.Position.X - coin.Position.X);
                //float yd = (float)(this.Position.Y - coin.Position.Y);

                //float sumRadius = (float)(this.Radius + coin.Radius);
                //float sqrRadius = sumRadius * sumRadius;

                //float distSqr = (xd * xd) + (yd * yd);

                //if (Math.Round(distSqr) < Math.Round(sqrRadius))
                //{
                //    return true;
                //}

                float xd = (float)(this.CenterX - coin.CenterX);
                float yd = (float)(this.CenterY - coin.CenterY);

                float sumRadius = (float)(this.Radius + coin.Radius);
                //float sqrRadius = sumRadius * sumRadius;

                double distSqr = Math.Sqrt((xd * xd) + (yd * yd));

                if (Math.Round(distSqr) <= Math.Round(sumRadius))
                {
                    return true;
                }
            }

            return false;
        }

        public void IntializeAllPositions()
        {
            this.Position = this.InitialPosition;
            this.X = Convert.ToInt32(this.InitialPosition.X);
            this.Y = Convert.ToInt32(this.InitialPosition.Y);
        }

        public void IntializeAllPositions(int x, int y)
        {
            this.InitialPosition.X = x;
            this.InitialPosition.Y = y;
            this.Position = this.InitialPosition;
        }

        public void ResolveCollision(BaseCoins coin)
        {
            // get the mtd
            Vector2D delta = (Position.Subtract(coin.Position));
            float d = delta.Lenght();
            // minimum translation distance to push balls apart after intersecting
            Vector2D mtd = delta.Multiply((float)(((coin.Radius + 1.0 + coin.Radius + 1.0) - d) / d));

            // resolve intersection --
            // inverse mass quantities
            float im1 = Weight;
            float im2 = coin.Weight;

            // push-pull them apart based off their mass
            Position = Position.Add((mtd.Multiply(im1 / (im1 + im2))));
            coin.Position = coin.Position.Subtract(mtd.Multiply(im2 / (im1 + im2)));

            //CheckCoinWallPosition(this);
            //CheckCoinWallPosition(coin);

            // impact speed
            Vector2D v = (this.TranslateVelocity.Subtract(coin.TranslateVelocity));
            float vn = v.Dot(mtd.Normalize());

            // sphere intersecting but moving away from each other already
            if (vn > 0.0f)
                return;

            // collision impulse
            float i = Math.Abs((float)((-(1.0f + 0.1) * vn) / (im1 + im2)));
            Vector2D impulse = mtd.Multiply(1);

            //double xSound = (float)(coin.Position.X - 300.0) / 300.0;
            // change in momentum
            this.TranslateVelocity = this.TranslateVelocity.Add(impulse.Multiply(im1));
            coin.TranslateVelocity = coin.TranslateVelocity.Subtract(impulse.Multiply(im2));
        }

        private void CheckCoinWallPosition(BaseCoins coin)
        {
            coin.Position.X = coin.X < 0 ? 2 : coin.Position.X;
            coin.Position.X = coin.X + coin.Width > 516 ? 516 - coin.Width - 5 : coin.Position.X;
            coin.Position.Y = coin.Y < 0 ? 2 : coin.Position.Y;
            coin.Position.Y = coin.Y + coin.Width > 516 ? 516 - coin.Width - 5 : coin.Position.Y;
        }
    }
}

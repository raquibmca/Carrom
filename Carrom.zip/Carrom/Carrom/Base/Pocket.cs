﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Base
{
    public class Pocket
    {
        private const int PocketLength = 26;

        public Pocket(int x, int y)
        {
            this.X = x; this.Y = y;
        }

        public int X { get; set; }
        public int Y { get; set; }

        public bool IsCoinFallIntoPocket(BaseCoins coin)
        {
            double xd = (double)(X - coin.CenterX);
            double yd = (double)(Y - coin.CenterY);

            int distance = (int)Math.Round(Math.Sqrt((xd * xd) + (yd * yd)));

            if (distance <= PocketLength)
            {
                coin.IsCoinInPocket = true;
                coin.TranslateVelocity.X =
                coin.TranslateVelocity.Y = 0.0;
                return true;
            }

            return false;
        }
    }
}

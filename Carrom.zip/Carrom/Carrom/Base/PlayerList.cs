﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;

namespace Base
{
    public class Utility
    {
        List<String> playersName = new List<String>();
        CultureInfo cultureInfo = null;
        TextInfo textInfo = null;
        public Utility()
        {
            cultureInfo = Thread.CurrentThread.CurrentCulture;
            textInfo = cultureInfo.TextInfo;
        }
        public List<String> GetPlayersName()
        {
            ModifyRegistry reg = new ModifyRegistry();
            string player1 = reg.Read("p1");
            string player2 = reg.Read("p2");
            if (player1 == null && player2 == null)
            {
                player1 = "Player1";
                player2 = "Player2";
                reg.Write("p1", textInfo.ToTitleCase(player1));
                reg.Write("p2", textInfo.ToTitleCase(player2));
            }
            playersName.Add(player1);
            playersName.Add(player2);

            return playersName;
        }

        public bool SavePlayerName(string player1, string player2)
        {
            ModifyRegistry reg = new ModifyRegistry();
            return reg.Write("p1", textInfo.ToTitleCase(player1)) && reg.Write("p2", textInfo.ToTitleCase(player2));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Base
{
    public enum CoinType
    {
        Coin,
        Stricker,
    }

    public enum ColorType
    {
        None,
        White,
        Black,
        Red
    }

    public enum State
    {
        NoMove,
        Move,
        OnHand
    }

    public enum CoinMaterialType
    {
        Wood,
        Fiber
    }
    public enum WallSide
    {
        Top,
        Left,
        Right,
        Bottom
    }

    public enum ForcedDirection
    {
        None,
        Up,
        Down,
        Left,
        Right
    }

    public enum RectangleCollision
    {
        None,
        Top,
        Bottom,
        Left,
        Right,
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight
    }

    public enum AimLinePosition
    {
        Top,
        Bottom
    }
}
